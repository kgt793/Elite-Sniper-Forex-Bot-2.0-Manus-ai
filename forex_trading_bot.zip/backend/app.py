from flask import Flask, jsonify, request
import sqlite3
import json
import os
import sys
from datetime import datetime, timedelta
import requests

# Import custom modules
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from exchange_rates_api import ExchangeRatesAPI
from signal_filter import SignalFilter
from breakout_detector import BreakoutDetector
from pattern_verifier import PatternVerifier

# Add the backend directory to the path to import the risk calculator
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from risk_calculator import RiskManagementCalculator

app = Flask(__name__)

# Initialize database
DATABASE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data', 'forex_bot.db')

def init_db():
    """Initialize the database with required tables if they don't exist"""
    os.makedirs(os.path.dirname(DATABASE_PATH), exist_ok=True)
    
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    # Create tables based on our database design
    cursor.executescript('''
    CREATE TABLE IF NOT EXISTS currency_pairs (
        pair_id INTEGER PRIMARY KEY,
        symbol VARCHAR(10) NOT NULL,
        base_currency VARCHAR(3) NOT NULL,
        quote_currency VARCHAR(3) NOT NULL,
        pip_value DECIMAL(10, 5) NOT NULL,
        average_spread DECIMAL(10, 5),
        trading_hours VARCHAR(100),
        description TEXT,
        pair_type VARCHAR(20) NOT NULL,
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS chart_patterns (
        pattern_id INTEGER PRIMARY KEY,
        name VARCHAR(50) NOT NULL,
        type VARCHAR(20) NOT NULL,
        description TEXT,
        formation_criteria TEXT,
        success_rate DECIMAL(5, 2),
        image_url VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS pattern_detections (
        detection_id INTEGER PRIMARY KEY,
        pair_id INTEGER NOT NULL,
        pattern_id INTEGER NOT NULL,
        timeframe VARCHAR(10) NOT NULL,
        detection_time TIMESTAMP NOT NULL,
        confidence_score DECIMAL(5, 2),
        price_at_detection DECIMAL(10, 5) NOT NULL,
        target_price DECIMAL(10, 5),
        stop_loss_price DECIMAL(10, 5),
        status VARCHAR(20) DEFAULT 'active',
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (pair_id) REFERENCES currency_pairs(pair_id),
        FOREIGN KEY (pattern_id) REFERENCES chart_patterns(pattern_id)
    );

    CREATE TABLE IF NOT EXISTS account (
        account_id INTEGER PRIMARY KEY,
        balance DECIMAL(15, 2) NOT NULL,
        previous_day_balance DECIMAL(15, 2),
        max_drawdown_amount DECIMAL(15, 2),
        current_drawdown DECIMAL(15, 2) DEFAULT 0,
        risk_percentage DECIMAL(5, 2) DEFAULT 0.2,
        drawdown_percentage DECIMAL(5, 2) DEFAULT 8.0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS trades (
        trade_id INTEGER PRIMARY KEY,
        pair_id INTEGER NOT NULL,
        detection_id INTEGER,
        entry_price DECIMAL(10, 5) NOT NULL,
        exit_price DECIMAL(10, 5),
        position_size DECIMAL(10, 5) NOT NULL,
        direction VARCHAR(10) NOT NULL,
        entry_time TIMESTAMP NOT NULL,
        exit_time TIMESTAMP,
        stop_loss DECIMAL(10, 5) NOT NULL,
        take_profit DECIMAL(10, 5),
        risk_amount DECIMAL(10, 2) NOT NULL,
        profit_loss DECIMAL(10, 2),
        status VARCHAR(20) DEFAULT 'open',
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (pair_id) REFERENCES currency_pairs(pair_id),
        FOREIGN KEY (detection_id) REFERENCES pattern_detections(detection_id)
    );

    CREATE TABLE IF NOT EXISTS historical_data (
        data_id INTEGER PRIMARY KEY,
        pair_id INTEGER NOT NULL,
        timeframe VARCHAR(10) NOT NULL,
        timestamp TIMESTAMP NOT NULL,
        open_price DECIMAL(10, 5) NOT NULL,
        high_price DECIMAL(10, 5) NOT NULL,
        low_price DECIMAL(10, 5) NOT NULL,
        close_price DECIMAL(10, 5) NOT NULL,
        volume INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (pair_id) REFERENCES currency_pairs(pair_id)
    );

    CREATE TABLE IF NOT EXISTS user_settings (
        setting_id INTEGER PRIMARY KEY,
        telegram_chat_id VARCHAR(50),
        notification_preferences TEXT,
        ui_preferences TEXT,
        api_keys TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    
    -- Create indexes for better performance
    CREATE INDEX IF NOT EXISTS idx_currency_pairs_symbol ON currency_pairs(symbol);
    CREATE INDEX IF NOT EXISTS idx_pattern_detections_pair_id ON pattern_detections(pair_id);
    CREATE INDEX IF NOT EXISTS idx_pattern_detections_pattern_id ON pattern_detections(pattern_id);
    CREATE INDEX IF NOT EXISTS idx_trades_pair_id ON trades(pair_id);
    CREATE INDEX IF NOT EXISTS idx_historical_data_pair_id_timestamp ON historical_data(pair_id, timestamp);
    CREATE INDEX IF NOT EXISTS idx_historical_data_timeframe ON historical_data(timeframe);
    ''')
    
    # Insert initial data if tables are empty
    if cursor.execute("SELECT COUNT(*) FROM currency_pairs").fetchone()[0] == 0:
        # Insert major currency pairs
        cursor.executemany(
            "INSERT INTO currency_pairs (symbol, base_currency, quote_currency, pip_value, average_spread, pair_type, description) VALUES (?, ?, ?, ?, ?, ?, ?)",
            [
                ('EUR/USD', 'EUR', 'USD', 10.0, 0.9, 'major', 'Euro / US Dollar'),
                ('USD/JPY', 'USD', 'JPY', 9.4, 1.2, 'major', 'US Dollar / Japanese Yen'),
                ('GBP/USD', 'GBP', 'USD', 10.0, 1.4, 'major', 'British Pound / US Dollar'),
                ('USD/CHF', 'USD', 'CHF', 9.8, 1.5, 'major', 'US Dollar / Swiss Franc'),
                ('USD/CAD', 'USD', 'CAD', 9.6, 1.6, 'major', 'US Dollar / Canadian Dollar'),
                ('AUD/USD', 'AUD', 'USD', 10.0, 1.3, 'major', 'Australian Dollar / US Dollar'),
                ('NZD/USD', 'NZD', 'USD', 10.0, 1.8, 'major', 'New Zealand Dollar / US Dollar'),
            ]
        )
        
        # Insert cross currency pairs
        cursor.executemany(
            "INSERT INTO currency_pairs (symbol, base_currency, quote_currency, pip_value, average_spread, pair_type, description) VALUES (?, ?, ?, ?, ?, ?, ?)",
            [
                ('EUR/GBP', 'EUR', 'GBP', 8.5, 1.9, 'cross', 'Euro / British Pound'),
                ('EUR/JPY', 'EUR', 'JPY', 8.7, 1.8, 'cross', 'Euro / Japanese Yen'),
                ('GBP/JPY', 'GBP', 'JPY', 8.4, 2.1, 'cross', 'British Pound / Japanese Yen'),
                ('EUR/CHF', 'EUR', 'CHF', 8.6, 2.0, 'cross', 'Euro / Swiss Franc'),
                ('EUR/CAD', 'EUR', 'CAD', 8.3, 2.2, 'cross', 'Euro / Canadian Dollar'),
                ('EUR/AUD', 'EUR', 'AUD', 8.2, 2.3, 'cross', 'Euro / Australian Dollar'),
                ('GBP/CHF', 'GBP', 'CHF', 8.1, 2.4, 'cross', 'British Pound / Swiss Franc'),
            ]
        )
        
        # Insert exotic currency pairs
        cursor.executemany(
            "INSERT INTO currency_pairs (symbol, base_currency, quote_currency, pip_value, average_spread, pair_type, description) VALUES (?, ?, ?, ?, ?, ?, ?)",
            [
                ('USD/MXN', 'USD', 'MXN', 5.0, 8.5, 'exotic', 'US Dollar / Mexican Peso'),
                ('USD/ZAR', 'USD', 'ZAR', 4.8, 12.3, 'exotic', 'US Dollar / South African Rand'),
                ('USD/TRY', 'USD', 'TRY', 4.5, 15.2, 'exotic', 'US Dollar / Turkish Lira'),
                ('USD/SGD', 'USD', 'SGD', 6.2, 5.8, 'exotic', 'US Dollar / Singapore Dollar'),
                ('USD/HKD', 'USD', 'HKD', 6.5, 4.2, 'exotic', 'US Dollar / Hong Kong Dollar'),
            ]
        )
    
    if cursor.execute("SELECT COUNT(*) FROM chart_patterns").fetchone()[0] == 0:
        # Insert chart patterns
        cursor.executemany(
            "INSERT INTO chart_patterns (name, type, description, success_rate) VALUES (?, ?, ?, ?)",
            [
                ('Ascending Triangle', 'continuation', 'Horizontal resistance with rising support', 72.0),
                ('Descending Triangle', 'continuation', 'Horizontal support with falling resistance', 68.0),
                ('Symmetrical Triangle', 'bilateral', 'Converging support and resistance', 65.0),
                ('Flag', 'continuation', 'Parallel channel against trend', 70.0),
                ('Wedge', 'continuation', 'Converging channel against trend', 67.0),
                ('Double Top', 'reversal', 'Two peaks at resistance level', 76.0),
                ('Double Bottom', 'reversal', 'Two troughs at support level', 74.0),
                ('Head and Shoulders', 'reversal', 'Three peaks with middle peak higher', 78.0),
                ('Inverse Head and Shoulders', 'reversal', 'Three troughs with middle trough lower', 77.0),
                ('Rounded Top', 'reversal', 'Gradual, curved change from bullish to bearish', 62.0),
                ('Rounded Bottom', 'reversal', 'Gradual, curved change from bearish to bullish', 63.0),
                ('Cup and Handle', 'continuation', 'U-shaped pattern with small pullback', 69.0),
            ]
        )
    
    if cursor.execute("SELECT COUNT(*) FROM account").fetchone()[0] == 0:
        # Insert initial account data
        cursor.execute(
            "INSERT INTO account (balance, previous_day_balance, max_drawdown_amount, risk_percentage, drawdown_percentage) VALUES (?, ?, ?, ?, ?)",
            (5000.00, 5000.00, 400.00, 0.2, 8.0)
        )
    
    if cursor.execute("SELECT COUNT(*) FROM user_settings").fetchone()[0] == 0:
        # Insert default user settings
        default_notification_prefs = json.dumps({
            'pattern_alerts': True,
            'trade_alerts': True,
            'drawdown_alerts': True,
            'daily_summary': True
        })
        default_ui_prefs = json.dumps({
            'theme': 'dark',
            'default_timeframe': '1h',
            'default_pairs_filter': 'all'
        })
        default_api_keys = json.dumps({
            'forex_provider': '',
            'telegram_bot_token': ''
        })
        
        cursor.execute(
            "INSERT INTO user_settings (notification_preferences, ui_preferences, api_keys) VALUES (?, ?, ?)",
            (default_notification_prefs, default_ui_prefs, default_api_keys)
        )
    
    conn.commit()
    conn.close()

# Initialize the database on startup
init_db()

# Initialize components
risk_calculator = RiskManagementCalculator(5000, 0.2, 8)
exchange_api = ExchangeRatesAPI(api_key="ef6f59a6a8bfcb2d200e77fc573d2729")
signal_filter = SignalFilter()
breakout_detector = BreakoutDetector()
pattern_verifier = PatternVerifier()

# Set up database connections
conn = sqlite3.connect(DATABASE_PATH)
signal_filter.set_db_connection(conn)
breakout_detector.set_db_connection(conn)
conn.close()

# API Routes
@app.route('/api/detect-breakouts', methods=['GET'])
def detect_breakouts():
    """Detect breakouts from trend lines and support/resistance levels"""
    pair_symbol = request.args.get('symbol')
    timeframe = request.args.get('timeframe', '1h')
    
    if not pair_symbol:
        return jsonify({"error": "Currency pair symbol is required"}), 400
    
    conn = sqlite3.connect(DATABASE_PATH)
    breakout_detector.set_db_connection(conn)
    
    try:
        # Analyze pair for breakouts
        analysis = breakout_detector.analyze_pair(pair_symbol, timeframe)
        
        # Save detected breakouts to database
        if 'breakouts' in analysis and analysis['breakouts']:
            for breakout in analysis['breakouts']:
                breakout_detector.save_breakout_to_db(breakout, pair_symbol)
        
        return jsonify(analysis)
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500
    finally:
        conn.close()

@app.route('/api/verify-pattern', methods=['POST'])
def verify_pattern_from_image():
    """Verify chart pattern using TradingView screenshot"""
    if 'image' not in request.files:
        return jsonify({"error": "No image file provided"}), 400
    
    image_file = request.files['image']
    
    if image_file.filename == '':
        return jsonify({"error": "No image selected"}), 400
    
    try:
        # Save the uploaded image
        upload_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'uploads')
        os.makedirs(upload_dir, exist_ok=True)
        
        image_path = os.path.join(upload_dir, image_file.filename)
        image_file.save(image_path)
        
        # Analyze the image
        analysis = pattern_verifier.analyze_tradingview_screenshot(image_path)
        
        # Add the image path to the response
        analysis['image_path'] = image_path
        
        return jsonify(analysis)
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

@app.route('/api/update-forex-data', methods=['GET'])
def update_forex_data():
    """Update forex data from exchangeratesapi.io"""
    conn = sqlite3.connect(DATABASE_PATH)
    try:
        updated_count = exchange_api.update_forex_database(conn)
        return jsonify({
            "success": True,
            "message": f"Updated {updated_count} currency pairs with latest data",
            "updated_at": datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        })
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500
    finally:
        conn.close()

@app.route('/api/filtered-signals', methods=['GET'])
def get_filtered_signals():
    """Get filtered trading signals with confirmation"""
    min_confidence = request.args.get('min_confidence', 75, type=int)
    
    conn = sqlite3.connect(DATABASE_PATH)
    signal_filter.set_db_connection(conn)
    
    try:
        signals = signal_filter.filter_signals(min_confidence=min_confidence)
        return jsonify(signals)
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500
    finally:
        conn.close()

@app.route('/api/confirm-pattern', methods=['POST'])
def confirm_pattern():
    """Confirm a chart pattern using multiple indicators"""
    data = request.json
    detection_id = data.get('detection_id')
    
    if not detection_id:
        return jsonify({"error": "Detection ID is required"}), 400
    
    conn = sqlite3.connect(DATABASE_PATH)
    signal_filter.set_db_connection(conn)
    
    try:
        # Get pattern detection
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM pattern_detections WHERE detection_id = ?", (detection_id,))
        detection = cursor.fetchone()
        
        if not detection:
            return jsonify({"error": "Pattern detection not found"}), 404
        
        # Convert to dict
        columns = [column[0] for column in cursor.description]
        detection_dict = dict(zip(columns, detection))
        
        # Confirm pattern
        confirmation = signal_filter.confirm_pattern(detection_dict)
        
        # Update pattern status if confirmed
        if confirmation['confirmed']:
            signal_filter.update_pattern_detection_status(
                detection_id, 
                'confirmed', 
                notes=f"Confirmed with {confirmation['confidence']}% confidence: {', '.join(confirmation['reasons'])}"
            )
        
        return jsonify(confirmation)
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500
    finally:
        conn.close()

@app.route('/api/multi-timeframe-confirmation', methods=['GET'])
def get_multi_timeframe_confirmation():
    """Get multi-timeframe confirmation for a currency pair"""
    pair_symbol = request.args.get('symbol')
    detection_id = request.args.get('detection_id')
    
    if not pair_symbol:
        return jsonify({"error": "Currency pair symbol is required"}), 400
    
    conn = sqlite3.connect(DATABASE_PATH)
    signal_filter.set_db_connection(conn)
    
    try:
        # Get pattern detection if provided
        detection_dict = None
        if detection_id:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM pattern_detections WHERE detection_id = ?", (detection_id,))
            detection = cursor.fetchone()
            
            if detection:
                columns = [column[0] for column in cursor.description]
                detection_dict = dict(zip(columns, detection))
        
        # Get multi-timeframe confirmation
        confirmation = signal_filter.get_multi_timeframe_confirmation(pair_symbol, detection_dict)
        
        return jsonify(confirmation)
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500
    finally:
        conn.close()

@app.route('/api/currency-pairs', methods=['GET'])
def get_currency_pairs():
    """Get all currency pairs or filter by type"""
    pair_type = request.args.get('type', None)
    
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    if pair_type:
        cursor.execute("SELECT * FROM currency_pairs WHERE pair_type = ? AND is_active = 1", (pair_type,))
    else:
        cursor.execute("SELECT * FROM currency_pairs WHERE is_active = 1")
    
    pairs = [dict(row) for row in cursor.fetchall()]
    conn.close()
    
    return jsonify(pairs)

@app.route('/api/chart-patterns', methods=['GET'])
def get_chart_patterns():
    """Get all chart patterns or filter by type"""
    pattern_type = request.args.get('type', None)
    
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    if pattern_type:
        cursor.execute("SELECT * FROM chart_patterns WHERE type = ?", (pattern_type,))
    else:
        cursor.execute("SELECT * FROM chart_patterns")
    
    patterns = [dict(row) for row in cursor.fetchall()]
    conn.close()
    
    return jsonify(patterns)

@app.route('/api/pattern-detections', methods=['GET'])
def get_pattern_detections():
    """Get pattern detections for currency pairs"""
    pair_id = request.args.get('pair_id', None)
    pattern_id = request.args.get('pattern_id', None)
    status = request.args.get('status', 'active')
    
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    query = """
    SELECT pd.*, cp.symbol, cp.pair_type, p.name as pattern_name, p.type as pattern_type
    FROM pattern_detections pd
    JOIN currency_pairs cp ON pd.pair_id = cp.pair_id
    JOIN chart_patterns p ON pd.pattern_id = p.pattern_id
    WHERE pd.status = ?
    """
    params = [status]
    
    if pair_id:
        query += " AND pd.pair_id = ?"
        params.append(pair_id)
    
    if pattern_id:
        query += " AND pd.pattern_id = ?"
        params.append(pattern_id)
    
    query += " ORDER BY pd.detection_time DESC"
    
    cursor.execute(query, params)
    detections = [dict(row) for row in cursor.fetchall()]
    conn.close()
    
    return jsonify(detections)

@app.route('/api/account', methods=['GET'])
def get_account_info():
    """Get account information"""
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    cursor.execute("SELECT * FROM account ORDER BY account_id DESC LIMIT 1")
    account = dict(cursor.fetchone())
    conn.close()
    
    return jsonify(account)

@app.route('/api/calculate-position', methods=['POST'])
def calculate_position():
    """Calculate position size based on risk parameters"""
    data = request.json
    
    entry_price = float(data.get('entry_price'))
    stop_loss_price = float(data.get('stop_loss_price'))
    pair_symbol = data.get('pair_symbol')
    
    # Get pair information if provided
    pair_info = None
    if pair_symbol:
        conn = sqlite3.connect(DATABASE_PATH)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM currency_pairs WHERE symbol = ?", (pair_symbol,))
        pair_row = cursor.fetchone()
        if pair_row:
            pair_info = dict(pair_row)
        conn.close()
    
    # Calculate position size
    position_info = risk_calculator.calculate_position_size(entry_price, stop_loss_price, pair_info)
    
    # If take profit is provided, calculate risk/reward ratio
    if 'take_profit_price' in data:
        take_profit_price = float(data.get('take_profit_price'))
        
        # Calculate pip distances
        if entry_price > stop_loss_price:  # Long position
            stop_loss_pips = (entry_price - stop_loss_price) * 10000
            take_profit_pips = (take_profit_price - entry_price) * 10000
        else:  # Short position
            stop_loss_pips = (stop_loss_price - entry_price) * 10000
            take_profit_pips = (entry_price - take_profit_price) * 10000
        
        # Calculate risk/reward ratio
        risk_reward_ratio = take_profit_pips / stop_loss_pips if stop_loss_pips > 0 else 0
        position_info['risk_reward_ratio'] = risk_reward_ratio
        position_info['potential_profit'] = position_info['risk_amount'] * risk_reward_ratio
    
    return jsonify(position_info)

@app.route('/api/simulate-trade', methods=['POST'])
def simulate_trade():
    """Simulate a trade outcome"""
    data = request.json
    
    entry_price = float(data.get('entry_price'))
    position_size = float(data.get('position_size'))
    
    # Optional parameters
    take_profit_price = data.get('take_profit_price')
    stop_loss_price = data.get('stop_loss_price')
    actual_exit_price = data.get('actual_exit_price')
    pair_symbol = data.get('pair_symbol')
    
    # Convert string values to float if they exist
    if take_profit_price:
        take_profit_price = float(take_profit_price)
    if stop_loss_price:
        stop_loss_price = float(stop_loss_price)
    if actual_exit_price:
        actual_exit_price = float(actual_exit_price)
    
    # Get pair information if provided
    pair_info = None
    if pair_symbol:
        conn = sqlite3.connect(DATABASE_PATH)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM currency_pairs WHERE symbol = ?", (pair_symbol,))
        pair_row = cursor.fetchone()
        if pair_row:
            pair_info = dict(pair_row)
        conn.close()
    
    # Simulate trade
    trade_result = risk_calculator.simulate_trade_outcome(
        entry_price=entry_price,
        position_size=position_size,
        take_profit_price=take_profit_price,
        stop_loss_price=stop_loss_price,
        actual_exit_price=actual_exit_price,
        pair_info=pair_info
    )
    
    return jsonify(trade_result)

@app.route('/api/trades', methods=['GET'])
def get_trades():
    """Get trade history"""
    status = request.args.get('status', None)
    limit = request.args.get('limit', 50)
    
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    query = """
    SELECT t.*, cp.symbol, cp.pair_type
    FROM trades t
    JOIN currency_pairs cp ON t.pair_id = cp.pair_id
    """
    
    params = []
    if status:
        query += " WHERE t.status = ?"
        params.append(status)
    
    query += " ORDER BY t.entry_time DESC LIMIT ?"
    params.append(limit)
    
    cursor.execute(query, params)
    trades = [dict(row) for row in cursor.fetchall()]
    conn.close()
    
    return jsonify(trades)

@app.route('/api/user-settings', methods=['GET'])
def get_user_settings():
    """Get user settings"""
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    cursor.execute("SELECT * FROM user_settings ORDER BY setting_id DESC LIMIT 1")
    settings_row = cursor.fetchone()
    settings = dict(settings_row)
    
    # Parse JSON strings to objects
    settings['notification_preferences'] = json.loads(settings['notification_preferences'])
    settings['ui_preferences'] = json.loads(settings['ui_preferences'])
    settings['api_keys'] = json.loads(settings['api_keys'])
    
    conn.close()
    
    return jsonify(settings)

@app.route('/api/user-settings', methods=['PUT'])
def update_user_settings():
    """Update user settings"""
    data = request.json
    
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    # Get current settings
    cursor.execute("SELECT * FROM user_settings ORDER BY setting_id DESC LIMIT 1")
    settings_row = cursor.fetchone()
    setting_id = settings_row[0]
    
    # Update settings
    updates = {}
    
    if 'telegram_chat_id' in data:
        updates['telegram_chat_id'] = data['telegram_chat_id']
    
    if 'notification_preferences' in data:
        updates['notification_preferences'] = json.dumps(data['notification_preferences'])
    
    if 'ui_preferences' in data:
        updates['ui_preferences'] = json.dumps(data['ui_preferences'])
    
    if 'api_keys' in data:
        updates['api_keys'] = json.dumps(data['api_keys'])
    
    if updates:
        updates['updated_at'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        set_clause = ', '.join([f"{key} = ?" for key in updates.keys()])
        values = list(updates.values())
        
        cursor.execute(f"UPDATE user_settings SET {set_clause} WHERE setting_id = ?", values + [setting_id])
        conn.commit()
    
    conn.close()
    
    return jsonify({"success": True, "message": "Settings updated successfully"})

@app.route('/api/forex-data', methods=['GET'])
def get_forex_data():
    """Get historical forex data for a currency pair"""
    pair_symbol = request.args.get('symbol')
    timeframe = request.args.get('timeframe', '1h')
    limit = int(request.args.get('limit', 100))
    
    if not pair_symbol:
        return jsonify({"error": "Currency pair symbol is required"}), 400
    
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    # Get pair_id from symbol
    cursor.execute("SELECT pair_id FROM currency_pairs WHERE symbol = ?", (pair_symbol,))
    pair_row = cursor.fetchone()
    
    if not pair_row:
        conn.close()
        return jsonify({"error": "Currency pair not found"}), 404
    
    pair_id = pair_row['pair_id']
    
    # Get historical data
    cursor.execute(
        """
        SELECT * FROM historical_data 
        WHERE pair_id = ? AND timeframe = ? 
        ORDER BY timestamp DESC LIMIT ?
        """, 
        (pair_id, timeframe, limit)
    )
    
    data = [dict(row) for row in cursor.fetchall()]
    conn.close()
    
    # If no data is found, try to fetch from external API
    if not data:
        # This would be implemented with a real API in production
        # For now, we'll return a placeholder message
        return jsonify({"message": "No historical data available. Would fetch from external API in production."}), 404
    
    return jsonify(data)

@app.route('/api/detect-patterns', methods=['POST'])
def detect_patterns():
    """Detect chart patterns in historical data"""
    data = request.json
    pair_symbol = data.get('pair_symbol')
    timeframe = data.get('timeframe', '1h')
    
    if not pair_symbol:
        return jsonify({"error": "Currency pair symbol is required"}), 400
    
    # In a real implementation, this would analyze historical data to detect patterns
    # For now, we'll return placeholder data
    
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    # Get pair_id from symbol
    cursor.execute("SELECT pair_id FROM currency_pairs WHERE symbol = ?", (pair_symbol,))
    pair_row = cursor.fetchone()
    
    if not pair_row:
        conn.close()
        return jsonify({"error": "Currency pair not found"}), 404
    
    pair_id = pair_row['pair_id']
    
    # Get random patterns for demonstration
    cursor.execute("SELECT pattern_id, name, type FROM chart_patterns ORDER BY RANDOM() LIMIT 2")
    patterns = [dict(row) for row in cursor.fetchall()]
    
    # Create pattern detections
    detections = []
    current_price = 1.2000  # Placeholder price
    
    for pattern in patterns:
        detection = {
            "pair_id": pair_id,
            "pair_symbol": pair_symbol,
            "pattern_id": pattern['pattern_id'],
            "pattern_name": pattern['name'],
            "pattern_type": pattern['type'],
            "timeframe": timeframe,
            "detection_time": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            "confidence_score": round(70 + 20 * (0.5 - 0.5), 2),  # Random score between 70-90
            "price_at_detection": current_price,
        }
        
        # Add target and stop loss based on pattern type
        if pattern['type'] == 'continuation':
            detection["target_price"] = round(current_price * 1.01, 5)
            detection["stop_loss_price"] = round(current_price * 0.995, 5)
        elif pattern['type'] == 'reversal':
            detection["target_price"] = round(current_price * 0.99, 5)
            detection["stop_loss_price"] = round(current_price * 1.005, 5)
        else:  # bilateral
            # For bilateral patterns, we don't set target/stop loss until breakout direction is confirmed
            detection["target_price"] = None
            detection["stop_loss_price"] = None
        
        detections.append(detection)
    
    conn.close()
    
    return jsonify(detections)

@app.route('/api/telegram/webhook', methods=['POST'])
def telegram_webhook():
    """Handle incoming messages from Telegram"""
    data = request.json
    
    # In a real implementation, this would process Telegram messages
    # For now, we'll return a placeholder response
    
    return jsonify({
        "success": True,
        "message": "Telegram webhook received",
        "data": data
    })

@app.route('/api/telegram/send', methods=['POST'])
def telegram_send():
    """Send message to Telegram chat"""
    data = request.json
    message = data.get('message')
    
    if not message:
        return jsonify({"error": "Message is required"}), 400
    
    # In a real implementation, this would send a message to the Telegram chat
    # For now, we'll return a placeholder response
    
    return jsonify({
        "success": True,
        "message": "Message would be sent to Telegram in production",
        "content": message
    })

# Serve static files from the frontend directory
@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve_frontend(path):
    if path == "" or path == "/":
        return app.send_static_file('index.html')
    else:
        return app.send_static_file(path)

# Set the static folder to the frontend directory
app.static_folder = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'frontend')

if __name__ == '__main__':
    # Get port from environment variable for Render compatibility
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)
