import os
import json
import logging
import requests
import sqlite3
import sys
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes, MessageHandler, filters

# Add the backend directory to the path to import the risk calculator
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from risk_calculator import RiskManagementCalculator

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Database path
DATABASE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data', 'forex_bot.db')

# Initialize risk calculator
risk_calculator = RiskManagementCalculator(5000, 0.2, 8)

# Helper functions
def get_db_connection():
    """Create a database connection"""
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def get_account_info():
    """Get account information from the database"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM account ORDER BY account_id DESC LIMIT 1")
    account = dict(cursor.fetchone())
    conn.close()
    return account

def get_currency_pairs(pair_type=None):
    """Get currency pairs from the database"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    if pair_type:
        cursor.execute("SELECT * FROM currency_pairs WHERE pair_type = ? AND is_active = 1", (pair_type,))
    else:
        cursor.execute("SELECT * FROM currency_pairs WHERE is_active = 1")
    
    pairs = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return pairs

def get_chart_patterns(pattern_type=None):
    """Get chart patterns from the database"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    if pattern_type:
        cursor.execute("SELECT * FROM chart_patterns WHERE type = ?", (pattern_type,))
    else:
        cursor.execute("SELECT * FROM chart_patterns")
    
    patterns = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return patterns

def get_pattern_detections(pair_symbol=None, status='active'):
    """Get pattern detections from the database"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    query = """
    SELECT pd.*, cp.symbol, cp.pair_type, p.name as pattern_name, p.type as pattern_type
    FROM pattern_detections pd
    JOIN currency_pairs cp ON pd.pair_id = cp.pair_id
    JOIN chart_patterns p ON pd.pattern_id = p.pattern_id
    WHERE pd.status = ?
    """
    params = [status]
    
    if pair_symbol:
        query += " AND cp.symbol = ?"
        params.append(pair_symbol)
    
    query += " ORDER BY pd.detection_time DESC"
    
    cursor.execute(query, params)
    detections = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return detections

def calculate_position_size(entry_price, stop_loss_price, pair_symbol=None):
    """Calculate position size based on risk parameters"""
    # Get pair information if provided
    pair_info = None
    if pair_symbol:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM currency_pairs WHERE symbol = ?", (pair_symbol,))
        pair_row = cursor.fetchone()
        if pair_row:
            pair_info = dict(pair_row)
        conn.close()
    
    # Calculate position size
    position_info = risk_calculator.calculate_position_size(entry_price, stop_loss_price, pair_info)
    return position_info

# Command handlers
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send a message when the command /start is issued."""
    user = update.effective_user
    await update.message.reply_html(
        f"Hi {user.mention_html()}! I'm your Forex Trading Bot.\n\n"
        f"I can help you monitor currency pairs, detect chart patterns, and calculate position sizes based on your risk management rules.\n\n"
        f"Use /help to see available commands."
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send a message when the command /help is issued."""
    help_text = (
        "Available commands:\n\n"
        "/status - Check bot status and account information\n"
        "/pairs - List all available currency pairs\n"
        "/patterns - List all detected chart patterns\n"
        "/calculate - Calculate position size for a trade\n"
        "/settings - View and update your settings\n\n"
        "Example usage:\n"
        "/calculate EUR/USD 1.1200 1.1150 - Calculate position size for EUR/USD with entry at 1.1200 and stop loss at 1.1150"
    )
    await update.message.reply_text(help_text)

async def status_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send account status information."""
    account = get_account_info()
    
    status_text = (
        "📊 *Account Status*\n\n"
        f"💰 Balance: ${account['balance']:.2f}\n"
        f"⚠️ Risk per trade: {account['risk_percentage']}%\n"
        f"🔴 Max drawdown: {account['drawdown_percentage']}%\n"
        f"📉 Current drawdown: ${account['current_drawdown']:.2f}\n\n"
        f"Risk amount per trade: ${account['balance'] * account['risk_percentage'] / 100:.2f}\n"
        f"Max drawdown amount: ${account['max_drawdown_amount']:.2f}"
    )
    
    await update.message.reply_markdown(status_text)

async def pairs_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """List available currency pairs."""
    # Check if a specific type was requested
    pair_type = None
    if context.args and context.args[0].lower() in ['major', 'cross', 'exotic']:
        pair_type = context.args[0].lower()
    
    pairs = get_currency_pairs(pair_type)
    
    if not pairs:
        await update.message.reply_text("No currency pairs found.")
        return
    
    # Create keyboard with pair types
    keyboard = [
        [
            InlineKeyboardButton("All", callback_data="pairs_all"),
            InlineKeyboardButton("Major", callback_data="pairs_major"),
            InlineKeyboardButton("Cross", callback_data="pairs_cross"),
            InlineKeyboardButton("Exotic", callback_data="pairs_exotic"),
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    # Format the message
    type_text = f" ({pair_type.capitalize()})" if pair_type else ""
    message = f"📊 *Available Currency Pairs{type_text}*\n\n"
    
    for pair in pairs[:15]:  # Limit to 15 pairs to avoid message too long
        message += f"• {pair['symbol']} - {pair['description']}\n"
    
    if len(pairs) > 15:
        message += f"\n_...and {len(pairs) - 15} more pairs_"
    
    await update.message.reply_markdown(message, reply_markup=reply_markup)

async def patterns_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """List detected chart patterns."""
    # Check if a specific pair was requested
    pair_symbol = None
    if context.args:
        pair_symbol = context.args[0].upper()
    
    detections = get_pattern_detections(pair_symbol)
    
    if not detections:
        no_pattern_text = f"No active pattern detections found"
        if pair_symbol:
            no_pattern_text += f" for {pair_symbol}"
        await update.message.reply_text(no_pattern_text)
        return
    
    # Format the message
    pair_text = f" for {pair_symbol}" if pair_symbol else ""
    message = f"📈 *Detected Chart Patterns{pair_text}*\n\n"
    
    for detection in detections[:10]:  # Limit to 10 detections
        pattern_type_emoji = "🔄" if detection['pattern_type'] == 'continuation' else "🔃" if detection['pattern_type'] == 'reversal' else "↔️"
        message += (
            f"{pattern_type_emoji} *{detection['symbol']}* - {detection['pattern_name']}\n"
            f"   Price: {detection['price_at_detection']}\n"
            f"   Confidence: {detection['confidence_score']}%\n"
            f"   Detected: {detection['detection_time']}\n\n"
        )
    
    if len(detections) > 10:
        message += f"_...and {len(detections) - 10} more patterns_"
    
    # Create keyboard with pattern types
    keyboard = [
        [
            InlineKeyboardButton("All Patterns", callback_data="patterns_all"),
            InlineKeyboardButton("Continuation", callback_data="patterns_continuation"),
            InlineKeyboardButton("Reversal", callback_data="patterns_reversal"),
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_markdown(message, reply_markup=reply_markup)

async def calculate_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Calculate position size for a trade."""
    # Check if arguments are provided
    if len(context.args) < 3:
        await update.message.reply_text(
            "Please provide currency pair, entry price, and stop loss price.\n"
            "Example: /calculate EUR/USD 1.1200 1.1150"
        )
        return
    
    try:
        pair_symbol = context.args[0].upper()
        entry_price = float(context.args[1])
        stop_loss_price = float(context.args[2])
        
        # Optional take profit price
        take_profit_price = None
        if len(context.args) > 3:
            take_profit_price = float(context.args[3])
        
        # Calculate position size
        position_info = calculate_position_size(entry_price, stop_loss_price, pair_symbol)
        
        # Calculate risk/reward ratio if take profit is provided
        risk_reward_text = ""
        if take_profit_price:
            # Calculate pip distances
            if entry_price > stop_loss_price:  # Long position
                stop_loss_pips = (entry_price - stop_loss_price) * 10000
                take_profit_pips = (take_profit_price - entry_price) * 10000
            else:  # Short position
                stop_loss_pips = (stop_loss_price - entry_price) * 10000
                take_profit_pips = (entry_price - take_profit_price) * 10000
            
            # Calculate risk/reward ratio
            risk_reward_ratio = take_profit_pips / stop_loss_pips if stop_loss_pips > 0 else 0
            potential_profit = position_info['risk_amount'] * risk_reward_ratio
            
            risk_reward_text = (
                f"\n📊 *Risk/Reward Analysis*\n"
                f"Risk/Reward Ratio: 1:{risk_reward_ratio:.2f}\n"
                f"Potential Profit: ${potential_profit:.2f}"
            )
        
        # Format the message
        message = (
            f"🧮 *Position Size Calculation for {pair_symbol}*\n\n"
            f"💰 Risk Amount: ${position_info['risk_amount']:.2f}\n"
            f"📏 Position Size: {position_info['position_size']:.2f} lots\n"
            f"📉 Stop Loss Distance: {position_info['stop_loss_pips']:.1f} pips\n"
            f"{risk_reward_text}"
        )
        
        await update.message.reply_markdown(message)
    
    except ValueError:
        await update.message.reply_text(
            "Invalid input. Please provide numeric values for prices.\n"
            "Example: /calculate EUR/USD 1.1200 1.1150"
        )
    except Exception as e:
        await update.message.reply_text(f"Error calculating position size: {str(e)}")

async def settings_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """View and update settings."""
    # Get current settings from database
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM user_settings ORDER BY setting_id DESC LIMIT 1")
    settings_row = cursor.fetchone()
    settings = dict(settings_row)
    
    # Parse JSON strings to objects
    notification_prefs = json.loads(settings['notification_preferences'])
    ui_prefs = json.loads(settings['ui_preferences'])
    api_keys = json.loads(settings['api_keys'])
    
    conn.close()
    
    # Format the message
    message = (
        f"⚙️ *Bot Settings*\n\n"
        f"*Notification Preferences*\n"
        f"• Pattern Alerts: {'✅' if notification_prefs.get('pattern_alerts', True) else '❌'}\n"
        f"• Trade Alerts: {'✅' if notification_prefs.get('trade_alerts', True) else '❌'}\n"
        f"• Drawdown Alerts: {'✅' if notification_prefs.get('drawdown_alerts', True) else '❌'}\n"
        f"• Daily Summary: {'✅' if notification_prefs.get('daily_summary', True) else '❌'}\n\n"
        f"*UI Preferences*\n"
        f"• Theme: {ui_prefs.get('theme', 'dark')}\n"
        f"• Default Timeframe: {ui_prefs.get('default_timeframe', '1h')}\n\n"
        f"Use /settings update to change settings."
    )
    
    await update.message.reply_markdown(message)

# Callback query handler
async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle button callbacks."""
    query = update.callback_query
    await query.answer()
    
    # Parse the callback data
    data = query.data.split('_')
    command = data[0]
    
    if command == 'pairs':
        # Handle currency pair filtering
        pair_type = data[1] if data[1] != 'all' else None
        pairs = get_currency_pairs(pair_type)
        
        if not pairs:
            await query.edit_message_text("No currency pairs found.")
            return
        
        # Format the message
        type_text = f" ({pair_type.capitalize()})" if pair_type else ""
        message = f"📊 *Available Currency Pairs{type_text}*\n\n"
        
        for pair in pairs[:15]:  # Limit to 15 pairs
            message += f"• {pair['symbol']} - {pair['description']}\n"
        
        if len(pairs) > 15:
            message += f"\n_...and {len(pairs) - 15} more pairs_"
        
        # Keep the same keyboard
        await query.edit_message_text(message, reply_markup=query.message.reply_markup, parse_mode='Markdown')
    
    elif command == 'patterns':
        # Handle pattern type filtering
        pattern_type = data[1] if data[1] != 'all' else None
        
        # Get all detections
        all_detections = get_pattern_detections()
        
        # Filter by pattern type if needed
        if pattern_type:
            detections = [d for d in all_detections if d['pattern_type'] == pattern_type]
        else:
            detections = all_detections
        
        if not detections:
            no_pattern_text = f"No active pattern detections found"
            if pattern_type:
                no_pattern_text += f" with type '{pattern_type}'"
            await query.edit_message_text(no_pattern_text)
            return
        
        # Format the message
        type_text = f" ({pattern_type})" if pattern_type else ""
        message = f"📈 *Detected Chart Patterns{type_text}*\n\n"
        
        for detection in detections[:10]:  # Limit to 10 detections
            pattern_type_emoji = "🔄" if detection['pattern_type'] == 'continuation' else "🔃" if detection['pattern_type'] == 'reversal' else "↔️"
            message += (
                f"{pattern_type_emoji} *{detection['symbol']}* - {detection['pattern_name']}\n"
                f"   Price: {detection['price_at_detection']}\n"
                f"   Confidence: {detection['confidence_score']}%\n"
                f"   Detected: {detection['detection_time']}\n\n"
            )
        
        if len(detections) > 10:
            message += f"_...and {len(detections) - 10} more patterns_"
        
        # Keep the same keyboard
        await query.edit_message_text(message, reply_markup=query.message.reply_markup, parse_mode='Markdown')

# Error handler
async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Log errors caused by updates."""
    logger.error(f"Update {update} caused error {context.error}")

def main() -> None:
    """Start the bot."""
    # Get bot token from settings
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT api_keys FROM user_settings ORDER BY setting_id DESC LIMIT 1")
    settings_row = cursor.fetchone()
    api_keys = json.loads(settings_row['api_keys'])
    conn.close()
    
    token = api_keys.get('telegram_bot_token', '')
    
    if not token:
        logger.error("Telegram bot token not found in settings")
        return
    
    # Create the Application
    application = Application.builder().token(token).build()

    # Add command handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("status", status_command))
    application.add_handler(CommandHandler("pairs", pairs_command))
    application.add_handler(CommandHandler("patterns", patterns_command))
    application.add_handler(CommandHandler("calculate", calculate_command))
    application.add_handler(CommandHandler("settings", settings_command))
    
    # Add callback query handler
    application.add_handler(CallbackQueryHandler(button_callback))
    
    # Add error handler
    application.add_error_handler(error_handler)

    # Run the bot until the user presses Ctrl-C
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()
